package model;

public class PlantStatistics {

}
