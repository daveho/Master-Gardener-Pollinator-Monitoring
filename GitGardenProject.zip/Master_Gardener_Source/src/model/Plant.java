package model;

public class Plant {

}
